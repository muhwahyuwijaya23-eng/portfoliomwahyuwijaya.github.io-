// app/src/main/java/com/example/aplikasirtku/AccountActivity.java
package com.example.aplikasirtku;

import android.content.Context; // Tambahkan import ini
import android.content.Intent;
import android.content.SharedPreferences; // Tambahkan import ini
import android.os.Bundle;
import android.util.Log; // Tambahkan import ini
import android.view.MenuItem;
import android.widget.TextView; // Tambahkan import ini
import android.widget.Toast; // Tambahkan import ini

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.material.bottomnavigation.BottomNavigationView;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class AccountActivity extends AppCompatActivity {

    private TextView tvNama, tvAlamat, tvRTRW, tvNoTelepon;
    private int userId; // Untuk menyimpan user_id yang didapat dari SharedPreferences

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_account);

        // Inisialisasi TextViews
        tvNama = findViewById(R.id.tv_nama);
        tvAlamat = findViewById(R.id.tv_alamat);
        tvRTRW = findViewById(R.id.tv_rtrw);
        tvNoTelepon = findViewById(R.id.tv_notelepon);

        // Ambil user_id dari SharedPreferences
        SharedPreferences sharedPreferences = getSharedPreferences("LoginData", Context.MODE_PRIVATE);
        userId = sharedPreferences.getInt("user_id", -1); // -1 adalah nilai default jika tidak ditemukan

        if (userId != -1) {
            loadUserData(userId); // Panggil method untuk memuat data
        } else {
            Toast.makeText(this, "User ID tidak ditemukan. Harap login kembali.", Toast.LENGTH_LONG).show();
            // Opsional: Arahkan kembali ke LoginActivity jika user_id tidak ada
            Intent intent = new Intent(AccountActivity.this, LoginActivity.class);
            startActivity(intent);
            finish();
        }

        BottomNavigationView bottomNavigationView = findViewById(R.id.bottom_navigation_account);
        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                Intent intent;
                int itemId = item.getItemId();
                if (itemId == R.id.navigation_home) {
                    intent = new Intent(AccountActivity.this, MainActivity.class);
                    startActivity(intent);
                    finish(); // Tutup activity ini agar tidak menumpuk
                    return true;
                } else if (itemId == R.id.navigation_person) {
                    // Current activity is Account
                    return true;
                } else if (itemId == R.id.navigation_notifications) {
                    intent = new Intent(AccountActivity.this, NotificationsActivity.class);
                    startActivity(intent);
                    finish(); // Tutup activity ini agar tidak menumpuk
                    return true;
                } else if (itemId == R.id.navigation_settings) {
                    intent = new Intent(AccountActivity.this, SettingActivity.class);
                    startActivity(intent);
                    finish(); // Tutup activity ini agar tidak menumpuk
                    return true;
                }
                return false;
            }
        });
        // Pastikan item yang dipilih tetap navigation_person saat AccountActivity aktif
        bottomNavigationView.setSelectedItemId(R.id.navigation_person);
    }

    // Method untuk memuat data pengguna dari API
    private void loadUserData(int userId) {
        StringRequest stringRequest = new StringRequest(Request.Method.POST, Constants.URL_GET_USER_DATA,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            JSONObject jsonObject = new JSONObject(response);
                            String status = jsonObject.getString("status");
                            String message = jsonObject.getString("message");

                            if (status.equals("success")) {
                                JSONObject userData = jsonObject.getJSONObject("data");
                                // Tampilkan data ke TextViews
                                tvNama.setText("Nama: " + userData.getString("nama"));
                                tvAlamat.setText("Alamat: " + userData.getString("alamat"));
                                tvRTRW.setText("RT/RW: " + userData.getString("rt") + "/" + userData.getString("rw"));
                                tvNoTelepon.setText("No. Telepon: " + userData.getString("no_telepon"));
                            } else {
                                Toast.makeText(AccountActivity.this, message, Toast.LENGTH_LONG).show();
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                            Toast.makeText(AccountActivity.this, "Error parsing JSON data pengguna: " + e.getMessage(), Toast.LENGTH_LONG).show();
                            Log.e("AccountActivity", "JSON parsing error: " + e.getMessage());
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(AccountActivity.this, "Error koneksi: " + error.getMessage(), Toast.LENGTH_LONG).show();
                        if (error.networkResponse != null) {
                            String responseBody = new String(error.networkResponse.data);
                            Log.e("VolleyError", "Response Body User Data: " + responseBody);
                        }
                    }
                }) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                params.put("user_id", String.valueOf(userId)); // Kirim user_id sebagai parameter POST
                return params;
            }
        };

        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);
    }
}