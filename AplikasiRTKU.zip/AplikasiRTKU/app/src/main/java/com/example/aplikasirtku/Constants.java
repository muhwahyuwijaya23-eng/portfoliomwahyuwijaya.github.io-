// app/src/main/java/com/example/aplikasirtku/Constants.java
package com.example.aplikasirtku; // Ganti dengan package aplikasi kamu

public class Constants {
    // Ganti 192.168.1.5 dengan IP Address laptop kamu
    // Pastikan laptop dan HP terhubung ke JARINGAN WIFI YANG SAMA
    public static final String BASE_URL = "http://192.168.8.151/pelayanan-rt/rtrw-api-android/"; // <-- Ini harus sesuai dengan folder XAMPP kamu

    public static final String URL_LOGIN = BASE_URL + "login.php";
    public static final String URL_REGISTER = BASE_URL + "register.php";
    public static final String URL_GET_USER_DATA = BASE_URL + "get_user_data.php";
    public static final String URL_GET_ALL_INFORMASI = BASE_URL + "get_all_informasi.php";
    public static final String URL_GET_INFORMASI_DETAIL = BASE_URL + "get_informasi_detail.php";
    public static final String URL_SUBMIT_KELUHAN = BASE_URL + "submit_keluhan.php";
    public static final String URL_SUBMIT_SURAT_PERMOHONAN = BASE_URL + "submit_surat_permohonan.php";
    public static final String URL_SUBMIT_KEPENDUDUKAN = BASE_URL + "submit_kependudukan.php";
    public static final String URL_GET_ALL_IURAN = BASE_URL + "get_all_iuran.php";
    public static final String URL_GET_IURAN_DETAIL = BASE_URL + "get_iuran_detail.php";
    public static final String URL_SUBMIT_PEMBAYARAN_IURAN = BASE_URL + "submit_pembayaran_iuran.php";
    public static final String URL_GET_PAYMENT_HISTORY = BASE_URL + "get_payment_history.php";
    public static final String URL_CHANGE_PASSWORD = BASE_URL + "change_password.php"; // <--- TAMBAHKAN INI
    public static final String URL_GET_WARGA_PROFILE = BASE_URL + "get_warga_profile.php"; // <--- TAMBAHKAN INI
    public static final String URL_UPDATE_WARGA_PROFILE = BASE_URL + "update_warga_profile.php"; // <--- TAMBAHKAN INI
    // Tambahkan URL untuk API lain di sini nanti
}