package com.example.aplikasirtku;

public class Informasi {
    private int id;
    private String judul;
    private String isi; // Meskipun tidak ditampilkan langsung di daftar, bisa berguna jika di passing
    private String tanggal; // Ini kolom 'tanggal' di DB
    private String createdAt; // Ini kolom 'created_at' di DB

    public Informasi(int id, String judul, String isi, String tanggal, String createdAt) {
        this.id = id;
        this.judul = judul;
        this.isi = isi;
        this.tanggal = tanggal;
        this.createdAt = createdAt;
    }

    // --- Getter Methods ---
    public int getId() {
        return id;
    }

    public String getJudul() {
        return judul;
    }

    public String getIsi() {
        return isi;
    }

    public String getTanggal() {
        return tanggal;
    }

    public String getCreatedAt() {
        return createdAt;
    }
}