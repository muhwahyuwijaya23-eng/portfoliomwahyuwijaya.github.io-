package com.example.aplikasirtku;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem; // Diperlukan untuk BottomNavigationView
import android.widget.ImageView; // Tambahkan import ini
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.bumptech.glide.Glide; // Tambahkan import ini
import com.google.android.material.bottomnavigation.BottomNavigationView; // Tambahkan import ini

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

import androidx.annotation.NonNull;
import android.content.Intent;

public class InformasiActivity extends AppCompatActivity { // Nama kelas diubah dari InformasiDetailActivity

    private ImageView ivInformasiGambar;
    private TextView tvJudul, tvTanggalPublikasi, tvCreatedAt, tvIsi; // Nama variabel disesuaikan
    private int informasiId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_informasi); // Menggunakan layout activity_informasi

        // Inisialisasi Views
        ivInformasiGambar = findViewById(R.id.iv_informasi_gambar);
        tvJudul = findViewById(R.id.tv_detail_judul);
        tvTanggalPublikasi = findViewById(R.id.tv_detail_tanggal_publikasi);
        tvCreatedAt = findViewById(R.id.tv_detail_created_at);
        tvIsi = findViewById(R.id.tv_detail_isi);

        // Ambil ID informasi dari Intent
        informasiId = getIntent().getIntExtra("informasi_id", -1);

        if (informasiId != -1) {
            loadInformasiData(informasiId); // Mengganti nama method
        } else {
            Toast.makeText(this, "ID Informasi tidak valid.", Toast.LENGTH_SHORT).show();
            finish(); // Tutup activity jika ID tidak valid
        }

        // Setup BottomNavigationView (Jika Activity ini memiliki Bottom Navigation)
        BottomNavigationView bottomNavigationView = findViewById(R.id.bottom_navigation_info);
        if (bottomNavigationView != null) { // Pastikan BottomNavigationView ada di layout
            bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
                @Override
                public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                    Intent intent;
                    int itemId = item.getItemId();
                    if (itemId == R.id.navigation_home) {
                        intent = new Intent(InformasiActivity.this, MainActivity.class);
                        startActivity(intent);
                        finish();
                        return true;
                    } else if (itemId == R.id.navigation_person) {
                        intent = new Intent(InformasiActivity.this, AccountActivity.class);
                        startActivity(intent);
                        finish();
                        return true;
                    } else if (itemId == R.id.navigation_notifications) {
                        intent = new Intent(InformasiActivity.this, NotificationsActivity.class);
                        startActivity(intent);
                        finish();
                        return true;
                    } else if (itemId == R.id.navigation_settings) {
                        intent = new Intent(InformasiActivity.this, SettingActivity.class);
                        startActivity(intent);
                        finish();
                        return true;
                    }
                    return false;
                }
            });
            // Tidak perlu setSelectedItemId di sini, karena ini detail view, bukan navigasi utama
            // Namun jika memang ingin item tertentu selalu aktif (misal home), bisa diset.
            // bottomNavigationView.setSelectedItemId(R.id.navigation_home); // Contoh
        }
    }

    private void loadInformasiData(int id) { // Nama method diubah
        StringRequest stringRequest = new StringRequest(Request.Method.POST, Constants.URL_GET_INFORMASI_DETAIL,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            JSONObject jsonObject = new JSONObject(response);
                            String status = jsonObject.getString("status");
                            String message = jsonObject.getString("message");

                            if (status.equals("success")) {
                                JSONObject data = jsonObject.getJSONObject("data");
                                tvJudul.setText(data.getString("judul"));
                                tvTanggalPublikasi.setText("Tanggal Publikasi: " + data.getString("tanggal"));
                                tvCreatedAt.setText("Dibuat Pada: " + data.getString("created_at"));
                                tvIsi.setText(data.getString("isi"));

                                // Load gambar menggunakan Glide
                                String imageUrl = data.getString("gambar");
                                if (!imageUrl.isEmpty()) {
                                    // Asumsi gambar disimpan di folder 'uploads' di root API Anda
                                    // Contoh: http://192.168.1.5/pelayanan-rt/uploads/nama_gambar.jpg
                                    String fullImageUrl = Constants.BASE_URL + "uploads/" + imageUrl; // Sesuaikan path 'uploads/'
                                    Glide.with(InformasiActivity.this)
                                            .load(fullImageUrl)
                                            .placeholder(R.drawable.placeholder_image) // Tampilan placeholder saat loading
                                            .error(R.drawable.placeholder_image) // Tampilan jika gagal load
                                            .into(ivInformasiGambar);
                                } else {
                                    // Jika tidak ada gambar, tampilkan placeholder atau sembunyikan ImageView
                                    ivInformasiGambar.setImageResource(R.drawable.placeholder_image);
                                }

                            } else {
                                Toast.makeText(InformasiActivity.this, message, Toast.LENGTH_LONG).show();
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                            Toast.makeText(InformasiActivity.this, "Error parsing JSON data informasi: " + e.getMessage(), Toast.LENGTH_LONG).show();
                            Log.e("InformasiActivity", "JSON Error: " + e.getMessage());
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(InformasiActivity.this, "Error koneksi: " + error.getMessage(), Toast.LENGTH_LONG).show();
                        if (error.networkResponse != null) {
                            String responseBody = new String(error.networkResponse.data);
                            Log.e("InformasiActivity", "Volley Error Response: " + responseBody);
                        }
                    }
                }) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                params.put("informasi_id", String.valueOf(id));
                return params;
            }
        };

        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);
    }
}