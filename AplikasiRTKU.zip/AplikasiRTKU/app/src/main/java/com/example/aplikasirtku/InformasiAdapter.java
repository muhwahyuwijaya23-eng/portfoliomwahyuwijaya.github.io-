package com.example.aplikasirtku;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class InformasiAdapter extends RecyclerView.Adapter<InformasiAdapter.InformasiViewHolder> {

    private Context context;
    private List<Informasi> informasiList;

    public InformasiAdapter(Context context, List<Informasi> informasiList) {
        this.context = context;
        this.informasiList = informasiList;
    }

    @NonNull
    @Override
    public InformasiViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_notification, parent, false);
        return new InformasiViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull InformasiViewHolder holder, int position) {
        Informasi informasi = informasiList.get(position);
        holder.tvJudul.setText(informasi.getJudul());
        holder.tvTanggal.setText("Tanggal Dibuat: " + informasi.getCreatedAt()); // Menampilkan created_at

        holder.itemContainer.setOnClickListener(v -> {
            // Saat item diklik, buka InformasiActivity
            Intent intent = new Intent(context, InformasiActivity.class); // <--- DIUBAH KE InformasiActivity
            intent.putExtra("informasi_id", informasi.getId()); // Kirim ID informasi
            context.startActivity(intent);
        });
    }

    @Override
    public int getItemCount() {
        return informasiList.size();
    }

    public static class InformasiViewHolder extends RecyclerView.ViewHolder {
        TextView tvJudul, tvTanggal;
        LinearLayout itemContainer;

        public InformasiViewHolder(@NonNull View itemView) {
            super(itemView);
            tvJudul = itemView.findViewById(R.id.tv_notification_judul);
            tvTanggal = itemView.findViewById(R.id.tv_notification_tanggal);
            itemContainer = itemView.findViewById(R.id.notification_item_container);
        }
    }
}