// app/src/main/java/com/example/aplikasirtku/Iuran.java
package com.example.aplikasirtku;

public class Iuran {
    private int id;
    private String judul;
    private String deskripsi;
    private int nominal;
    private String jatuhTempo;
    private String createdAt;
    private boolean isPaid; // <--- TAMBAHKAN INI
    private String paidDate; // <--- TAMBAHKAN INI (Tanggal bayar)

    public Iuran(int id, String judul, String deskripsi, int nominal, String jatuhTempo, String createdAt, boolean isPaid, String paidDate) {
        this.id = id;
        this.judul = judul;
        this.deskripsi = deskripsi;
        this.nominal = nominal;
        this.jatuhTempo = jatuhTempo;
        this.createdAt = createdAt;
        this.isPaid = isPaid;
        this.paidDate = paidDate;
    }

    // --- Getter Methods ---
    public int getId() { return id; }
    public String getJudul() { return judul; }
    public String getDeskripsi() { return deskripsi; }
    public int getNominal() { return nominal; }
    public String getJatuhTempo() { return jatuhTempo; }
    public String getCreatedAt() { return createdAt; }
    public boolean isPaid() { return isPaid; } // <--- TAMBAHKAN INI
    public String getPaidDate() { return paidDate; } // <--- TAMBAHKAN INI
}