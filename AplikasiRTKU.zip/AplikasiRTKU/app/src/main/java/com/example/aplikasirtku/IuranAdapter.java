// app/src/main/java/com/example/aplikasirtku/IuranAdapter.java
package com.example.aplikasirtku;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Paint;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.util.TypedValue; // <--- Tambahkan import ini
import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class IuranAdapter extends RecyclerView.Adapter<IuranAdapter.IuranViewHolder> {

    private Context context;
    private List<Iuran> iuranList;

    public IuranAdapter(Context context, List<Iuran> iuranList) {
        this.context = context;
        this.iuranList = iuranList;
    }

    @NonNull
    @Override
    public IuranViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_iuran, parent, false);
        return new IuranViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull IuranViewHolder holder, int position) {
        Iuran iuran = iuranList.get(position);
        holder.tvJudul.setText(iuran.getJudul());
        holder.tvJatuhTempo.setText("Jatuh Tempo: " + iuran.getJatuhTempo());

        if (iuran.isPaid()) {
            holder.tvJudul.setPaintFlags(holder.tvJudul.getPaintFlags() | Paint.STRIKE_THRU_TEXT_FLAG);
            holder.tvJatuhTempo.setPaintFlags(holder.tvJatuhTempo.getPaintFlags() | Paint.STRIKE_THRU_TEXT_FLAG);
            holder.itemContainer.setBackgroundColor(Color.parseColor("#E0E0E0")); // Latar belakang abu-abu
            holder.itemContainer.setClickable(false); // Nonaktifkan klik
            holder.itemContainer.setFocusable(false); // Nonaktifkan fokus
            holder.tvJudul.setTextColor(Color.GRAY);
            holder.tvJatuhTempo.setTextColor(Color.GRAY);
        } else {
            holder.tvJudul.setPaintFlags(holder.tvJudul.getPaintFlags() & (~Paint.STRIKE_THRU_TEXT_FLAG)); // Hapus coretan
            holder.tvJatuhTempo.setPaintFlags(holder.tvJatuhTempo.getPaintFlags() & (~Paint.STRIKE_THRU_TEXT_FLAG));

            // --- PERBAIKAN DI SINI ---
            // Mengambil drawable dari atribut tema selectableItemBackground
            TypedValue outValue = new TypedValue();
            context.getTheme().resolveAttribute(android.R.attr.selectableItemBackground, outValue, true);
            holder.itemContainer.setBackgroundResource(outValue.resourceId);
            // --- AKHIR PERBAIKAN ---

            holder.itemContainer.setClickable(true); // Aktifkan klik
            holder.itemContainer.setFocusable(true); // Aktifkan fokus
            holder.tvJudul.setTextColor(Color.BLACK); // Kembalikan warna default
            holder.tvJatuhTempo.setTextColor(Color.DKGRAY); // Kembalikan warna default

            holder.itemContainer.setOnClickListener(v -> {
                Intent intent = new Intent(context, PembayaranDetailActivity.class);
                intent.putExtra("iuran_id", iuran.getId());
                context.startActivity(intent);
            });
        }
    }

    @Override
    public int getItemCount() {
        return iuranList.size();
    }

    public static class IuranViewHolder extends RecyclerView.ViewHolder {
        TextView tvJudul, tvJatuhTempo;
        LinearLayout itemContainer;

        public IuranViewHolder(@NonNull View itemView) {
            super(itemView);
            tvJudul = itemView.findViewById(R.id.tv_iuran_judul);
            tvJatuhTempo = itemView.findViewById(R.id.tv_iuran_jatuh_tempo);
            itemContainer = itemView.findViewById(R.id.iuran_item_container);
        }
    }
}