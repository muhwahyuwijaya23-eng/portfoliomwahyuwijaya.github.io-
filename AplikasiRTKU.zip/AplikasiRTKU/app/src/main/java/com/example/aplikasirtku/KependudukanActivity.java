package com.example.aplikasirtku;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.material.bottomnavigation.BottomNavigationView;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class KependudukanActivity extends AppCompatActivity { // Pastikan nama kelas sesuai: KependudukanActivity

    private EditText etNamaLengkap, etKeperluan; // Nama variabel disesuaikan
    private Button btnKirim; // Nama variabel disesuaikan dengan teks di XML: btn_kirim
    private int userId; // Untuk menyimpan user_id dari SharedPreferences

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_kependudukan); // Pastikan nama layout benar

        etNamaLengkap = findViewById(R.id.et_judul); // Layout menggunakan id et_judul untuk Nama Lengkap
        etKeperluan = findViewById(R.id.et_isi);     // Layout menggunakan id et_isi untuk Keperluan
        btnKirim = findViewById(R.id.btn_kirim);     // ID tombol "KIRIM"

        // Ambil user_id dari SharedPreferences
        SharedPreferences sharedPreferences = getSharedPreferences("LoginData", Context.MODE_PRIVATE);
        userId = sharedPreferences.getInt("user_id", -1); // -1 adalah nilai default jika tidak ditemukan

        if (userId == -1) {
            Toast.makeText(this, "User ID tidak ditemukan. Harap login kembali.", Toast.LENGTH_LONG).show();
            // Opsional: Arahkan kembali ke LoginActivity jika user_id tidak ada
            Intent intent = new Intent(KependudukanActivity.this, LoginActivity.class);
            startActivity(intent);
            finish();
        }

        btnKirim.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                submitKependudukan();
            }
        });

        // Setup BottomNavigationView (sesuaikan jika ada di layout ini)
        BottomNavigationView bottomNavigationView = findViewById(R.id.bottom_navigation);
        if (bottomNavigationView != null) {
            bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
                @Override
                public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                    Intent intent;
                    int itemId = item.getItemId();
                    if (itemId == R.id.navigation_home) {
                        intent = new Intent(KependudukanActivity.this, MainActivity.class);
                        startActivity(intent);
                        finish();
                        return true;
                    } else if (itemId == R.id.navigation_person) {
                        intent = new Intent(KependudukanActivity.this, AccountActivity.class);
                        startActivity(intent);
                        finish();
                        return true;
                    } else if (itemId == R.id.navigation_notifications) {
                        intent = new Intent(KependudukanActivity.this, NotificationsActivity.class);
                        startActivity(intent);
                        finish();
                        return true;
                    } else if (itemId == R.id.navigation_settings) {
                        intent = new Intent(KependudukanActivity.this, SettingActivity.class);
                        startActivity(intent);
                        finish();
                        return true;
                    }
                    return false;
                }
            });
        }
    }

    private void submitKependudukan() {
        final String namaLengkap = etNamaLengkap.getText().toString().trim();
        final String keperluan = etKeperluan.getText().toString().trim();

        if (namaLengkap.isEmpty() || keperluan.isEmpty()) {
            Toast.makeText(this, "Nama Lengkap dan Keperluan tidak boleh kosong!", Toast.LENGTH_SHORT).show();
            return;
        }
        if (userId == -1) {
            Toast.makeText(this, "User ID tidak valid. Mohon login kembali.", Toast.LENGTH_SHORT).show();
            return;
        }

        StringRequest stringRequest = new StringRequest(Request.Method.POST, Constants.URL_SUBMIT_KEPENDUDUKAN,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            JSONObject jsonObject = new JSONObject(response);
                            String status = jsonObject.getString("status");
                            String message = jsonObject.getString("message");

                            if (status.equals("success")) {
                                Toast.makeText(KependudukanActivity.this, message, Toast.LENGTH_LONG).show();
                                finish(); // Kembali ke Activity sebelumnya setelah berhasil
                            } else {
                                Toast.makeText(KependudukanActivity.this, message, Toast.LENGTH_LONG).show();
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                            Toast.makeText(KependudukanActivity.this, "Error parsing JSON: " + e.getMessage(), Toast.LENGTH_LONG).show();
                            Log.e("KependudukanActivity", "JSON parsing error: " + e.getMessage());
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(KependudukanActivity.this, "Error koneksi: " + error.getMessage(), Toast.LENGTH_LONG).show();
                        if (error.networkResponse != null) {
                            String responseBody = new String(error.networkResponse.data);
                            Log.e("KependudukanActivity", "Volley Error Response: " + responseBody);
                        }
                    }
                }) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                params.put("user_id", String.valueOf(userId));
                params.put("nama_lengkap", namaLengkap); // Mengirim 'nama lengkap' sebagai 'judul'
                params.put("keperluan", keperluan);     // Mengirim 'keperluan' sebagai 'isi'
                return params;
            }
        };

        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);
    }
}