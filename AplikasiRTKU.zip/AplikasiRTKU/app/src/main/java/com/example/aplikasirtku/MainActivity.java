package com.example.aplikasirtku;

import android.content.Intent; // Pastikan ini diimpor
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;    // Pastikan ini diimpor
import android.widget.Button; // Pastikan ini diimpor
import android.widget.TextView; // Sudah ada di layout XML Anda

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.bottomnavigation.BottomNavigationView;

public class MainActivity extends AppCompatActivity {

    // Deklarasi tombol
    private Button btnIuran, btnKeluhan, btnKependudukan, btnSuratMenyurat;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Inisialisasi TextView (tv_title) jika Anda ingin menggunakannya
        TextView tvTitle = findViewById(R.id.tv_title);
        // Anda bisa mengatur teks atau melakukan hal lain dengan tvTitle di sini

        // Inisialisasi tombol-tombol
        btnIuran = findViewById(R.id.btn_iuran);
        btnKeluhan = findViewById(R.id.btn_keluhan);
        btnKependudukan = findViewById(R.id.btn_kependudukan);
        btnSuratMenyurat = findViewById(R.id.btn_surat_menyurat);

        // Menetapkan OnClickListener untuk setiap tombol
        btnIuran.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, PembayaranActivity.class);
                startActivity(intent);
            }
        });

        btnKeluhan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, KeluhanActivity.class);
                startActivity(intent);
            }
        });

        btnKependudukan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, KependudukanActivity.class);
                startActivity(intent);
            }
        });

        btnSuratMenyurat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, SuratmenyuratActivity.class);
                startActivity(intent);
            }
        });

        // Setup BottomNavigationView (bagian ini tetap seperti yang sudah ada)
        BottomNavigationView bottomNavigationView = findViewById(R.id.bottom_navigation);
        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                Intent intent;
                int itemId = item.getItemId();
                if (itemId == R.id.navigation_home) {
                    // Current activity is MainActivity (Home)
                    return true;
                } else if (itemId == R.id.navigation_person) {
                    intent = new Intent(MainActivity.this, AccountActivity.class);
                    startActivity(intent);
                    finish();
                    return true;
                } else if (itemId == R.id.navigation_notifications) {
                    intent = new Intent(MainActivity.this, NotificationsActivity.class);
                    startActivity(intent);
                    finish();
                    return true;
                } else if (itemId == R.id.navigation_settings) {
                    intent = new Intent(MainActivity.this, SettingActivity.class);
                    startActivity(intent);
                    finish();
                    return true;
                }
                return false;
            }
        });
        bottomNavigationView.setSelectedItemId(R.id.navigation_home); // Set item aktif ke Home
    }
}