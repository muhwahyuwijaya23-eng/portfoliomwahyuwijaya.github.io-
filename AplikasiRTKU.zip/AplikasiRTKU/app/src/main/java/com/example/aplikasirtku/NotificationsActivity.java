package com.example.aplikasirtku;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.material.bottomnavigation.BottomNavigationView;

import org.json.JSONArray; // Tambahkan import ini
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList; // Tambahkan import ini
import java.util.List;

public class NotificationsActivity extends AppCompatActivity {

    private RecyclerView rvNotifications;
    private InformasiAdapter adapter;
    private List<Informasi> informasiList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notifications);

        rvNotifications = findViewById(R.id.rv_notifications);
        rvNotifications.setLayoutManager(new LinearLayoutManager(this));
        informasiList = new ArrayList<>();
        adapter = new InformasiAdapter(this, informasiList);
        rvNotifications.setAdapter(adapter);

        loadNotifications(); // Panggil method untuk memuat notifikasi

        BottomNavigationView bottomNavigationView = findViewById(R.id.bottom_navigation_notifications);
        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                Intent intent;
                int itemId = item.getItemId();
                if (itemId == R.id.navigation_home) {
                    intent = new Intent(NotificationsActivity.this, MainActivity.class);
                    startActivity(intent);
                    finish();
                    return true;
                } else if (itemId == R.id.navigation_person) {
                    intent = new Intent(NotificationsActivity.this, AccountActivity.class);
                    startActivity(intent);
                    finish();
                    return true;
                } else if (itemId == R.id.navigation_notifications) {
                    // Current activity is Notifications
                    return true;
                } else if (itemId == R.id.navigation_settings) {
                    intent = new Intent(NotificationsActivity.this, SettingActivity.class);
                    startActivity(intent);
                    finish();
                    return true;
                }
                return false;
            }
        });
        bottomNavigationView.setSelectedItemId(R.id.navigation_notifications); // Set item yang aktif
    }

    private void loadNotifications() {
        StringRequest stringRequest = new StringRequest(Request.Method.GET, Constants.URL_GET_ALL_INFORMASI,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            JSONObject jsonObject = new JSONObject(response);
                            String status = jsonObject.getString("status");
                            String message = jsonObject.getString("message");

                            if (status.equals("success")) {
                                JSONArray jsonArray = jsonObject.getJSONArray("data");
                                informasiList.clear(); // Hapus data lama
                                for (int i = 0; i < jsonArray.length(); i++) {
                                    JSONObject infoObj = jsonArray.getJSONObject(i);
                                    int id = infoObj.getInt("id");
                                    String judul = infoObj.getString("judul");
                                    String isi = infoObj.getString("isi"); // Tetap ambil, meskipun tidak ditampilkan langsung
                                    String tanggal = infoObj.getString("tanggal");
                                    String createdAt = infoObj.getString("created_at");

                                    Informasi informasi = new Informasi(id, judul, isi, tanggal, createdAt);
                                    informasiList.add(informasi);
                                }
                                adapter.notifyDataSetChanged(); // Beri tahu adapter bahwa data telah berubah
                                if (informasiList.isEmpty()) {
                                    Toast.makeText(NotificationsActivity.this, "Tidak ada informasi yang tersedia.", Toast.LENGTH_SHORT).show();
                                }
                            } else {
                                Toast.makeText(NotificationsActivity.this, message, Toast.LENGTH_LONG).show();
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                            Toast.makeText(NotificationsActivity.this, "Error parsing JSON notifikasi: " + e.getMessage(), Toast.LENGTH_LONG).show();
                            Log.e("NotificationsActivity", "JSON parsing error: " + e.getMessage());
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(NotificationsActivity.this, "Error koneksi: " + error.getMessage(), Toast.LENGTH_LONG).show();
                        if (error.networkResponse != null) {
                            String responseBody = new String(error.networkResponse.data);
                            Log.e("VolleyError", "Response Body Notif List: " + responseBody);
                        }
                    }
                });

        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);
    }
}