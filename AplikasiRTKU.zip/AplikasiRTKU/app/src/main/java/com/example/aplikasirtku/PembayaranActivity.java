// app/src/main/java/com/example/aplikasirtku/PembayaranActivity.java
package com.example.aplikasirtku;

import android.content.Context; // Tambahkan import ini
import android.content.Intent;
import android.content.SharedPreferences; // Tambahkan import ini
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View; // Tambahkan import ini
import android.widget.ImageButton; // Tambahkan import ini
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.material.bottomnavigation.BottomNavigationView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap; // Tambahkan import ini
import java.util.List;
import java.util.Map; // Tambahkan import ini

public class PembayaranActivity extends AppCompatActivity {

    private RecyclerView rvIuran;
    private IuranAdapter adapter;
    private List<Iuran> iuranList;
    private ImageButton btnRiwayatPembayaran; // Deklarasi tombol riwayat
    private int userId; // Untuk menyimpan user_id

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pembayaran);

        rvIuran = findViewById(R.id.rv_iuran_list);
        rvIuran.setLayoutManager(new LinearLayoutManager(this));
        iuranList = new ArrayList<>();
        adapter = new IuranAdapter(this, iuranList);
        rvIuran.setAdapter(adapter);

        btnRiwayatPembayaran = findViewById(R.id.btn_riwayat_pembayaran); // Inisialisasi tombol riwayat

        // Ambil user_id dari SharedPreferences
        SharedPreferences sharedPreferences = getSharedPreferences("LoginData", Context.MODE_PRIVATE);
        userId = sharedPreferences.getInt("user_id", -1);

        if (userId == -1) {
            Toast.makeText(this, "User ID tidak ditemukan. Harap login kembali.", Toast.LENGTH_LONG).show();
            // Arahkan kembali ke LoginActivity jika user_id tidak ada
            Intent intent = new Intent(PembayaranActivity.this, LoginActivity.class);
            startActivity(intent);
            finish();
            return; // Penting: tambahkan return agar tidak melanjutkan proses tanpa user_id
        }

        loadIuranList(userId); // Memuat daftar iuran dengan user_id

        // Listener untuk tombol Riwayat Pembayaran
        btnRiwayatPembayaran.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(PembayaranActivity.this, StatusPembayaranActivity.class);
                startActivity(intent);
            }
        });

        // Setup BottomNavigationView
        BottomNavigationView bottomNavigationView = findViewById(R.id.bottom_navigation_pembayaran);
        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                Intent intent;
                int itemId = item.getItemId();
                if (itemId == R.id.navigation_home) {
                    intent = new Intent(PembayaranActivity.this, MainActivity.class);
                    startActivity(intent);
                    finish();
                    return true;
                } else if (itemId == R.id.navigation_person) {
                    intent = new Intent(PembayaranActivity.this, AccountActivity.class);
                    startActivity(intent);
                    finish();
                    return true;
                } else if (itemId == R.id.navigation_notifications) {
                    intent = new Intent(PembayaranActivity.this, NotificationsActivity.class);
                    startActivity(intent);
                    finish();
                    return true;
                } else if (itemId == R.id.navigation_settings) {
                    intent = new Intent(PembayaranActivity.this, SettingActivity.class);
                    startActivity(intent);
                    finish();
                    return true;
                }
                return false;
            }
        });
        // bottomNavigationView.setSelectedItemId(R.id.navigation_iuran); // Jika ada ID menu ini
    }

    // Perbarui method loadIuranList untuk menerima userId
    private void loadIuranList(int userId) {
        StringRequest stringRequest = new StringRequest(Request.Method.POST, Constants.URL_GET_ALL_IURAN, // <--- UBAH KE POST
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            JSONObject jsonObject = new JSONObject(response);
                            String status = jsonObject.getString("status");
                            String message = jsonObject.getString("message");

                            if (status.equals("success")) {
                                JSONArray jsonArray = jsonObject.getJSONArray("data");
                                iuranList.clear(); // Hapus data lama
                                for (int i = 0; i < jsonArray.length(); i++) {
                                    JSONObject iuranObj = jsonArray.getJSONObject(i);
                                    int id = iuranObj.getInt("id");
                                    String judul = iuranObj.getString("judul");
                                    String deskripsi = iuranObj.getString("deskripsi");
                                    int nominal = iuranObj.getInt("nominal");
                                    String jatuhTempo = iuranObj.getString("jatuh_tempo");
                                    String createdAt = iuranObj.getString("created_at");
                                    boolean isPaid = iuranObj.getBoolean("is_paid"); // <--- Ambil is_paid
                                    String paidDate = iuranObj.optString("paid_date", null); // <--- Ambil paid_date, bisa null

                                    Iuran iuran = new Iuran(id, judul, deskripsi, nominal, jatuhTempo, createdAt, isPaid, paidDate); // <--- Masukkan ke konstruktor
                                    iuranList.add(iuran);
                                }
                                adapter.notifyDataSetChanged();
                                if (iuranList.isEmpty()) {
                                    Toast.makeText(PembayaranActivity.this, "Tidak ada iuran yang tersedia.", Toast.LENGTH_SHORT).show();
                                }
                            } else {
                                Toast.makeText(PembayaranActivity.this, message, Toast.LENGTH_LONG).show();
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                            Toast.makeText(PembayaranActivity.this, "Error parsing JSON iuran: " + e.getMessage(), Toast.LENGTH_LONG).show();
                            Log.e("PembayaranActivity", "JSON parsing error: " + e.getMessage());
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(PembayaranActivity.this, "Error koneksi: " + error.getMessage(), Toast.LENGTH_LONG).show();
                        if (error.networkResponse != null) {
                            String responseBody = new String(error.networkResponse.data);
                            Log.e("VolleyError", "Response Body Iuran List: " + responseBody);
                        }
                    }
                }) {
            @Override
            protected Map<String, String> getParams() { // <--- Tambahkan method ini untuk POST
                Map<String, String> params = new HashMap<>();
                params.put("user_id", String.valueOf(userId)); // <--- Kirim user_id
                return params;
            }
        };

        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);
    }

    @Override
    protected void onResume() {
        super.onResume();
        // Memuat ulang daftar iuran setiap kali Activity dilanjutkan
        // Ini memastikan status pembayaran terbaru terlihat
        if (userId != -1) {
            loadIuranList(userId);
        }
    }
}