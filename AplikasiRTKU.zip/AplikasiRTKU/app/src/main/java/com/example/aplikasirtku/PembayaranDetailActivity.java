// app/src/main/java/com/example/aplikasirtku/PembayaranDetailActivity.java
package com.example.aplikasirtku;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Base64;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.text.NumberFormat;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

public class PembayaranDetailActivity extends AppCompatActivity {

    private TextView tvJudul, tvDeskripsi, tvNominal, tvJatuhTempo, tvCreatedAt;
    private EditText etJumlahBayar;
    private RadioGroup rgPaymentMethod;
    private RadioButton rbVirtual, rbCash;
    private LinearLayout layoutBuktiPembayaran;
    private ImageView ivBuktiBayarPreview;
    private Button btnPilihBukti, btnBayarIuran;

    private int iuranId;
    private int userId;
    private Bitmap selectedBuktiBitmap; // Untuk menyimpan bitmap gambar bukti pembayaran

    // ActivityResultLauncher untuk memilih gambar dari galeri
    private ActivityResultLauncher<Intent> pickImageLauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            result -> {
                if (result.getResultCode() == Activity.RESULT_OK && result.getData() != null) {
                    Uri imageUri = result.getData().getData();
                    try {
                        selectedBuktiBitmap = MediaStore.Images.Media.getBitmap(this.getContentResolver(), imageUri);
                        ivBuktiBayarPreview.setImageBitmap(selectedBuktiBitmap);
                    } catch (IOException e) {
                        e.printStackTrace();
                        Toast.makeText(this, "Gagal memuat gambar", Toast.LENGTH_SHORT).show();
                    }
                }
            }
    );

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pembayaran_detail);

        // Inisialisasi Views Detail Iuran
        tvJudul = findViewById(R.id.tv_detail_iuran_judul);
        tvDeskripsi = findViewById(R.id.tv_detail_iuran_deskripsi);
        tvNominal = findViewById(R.id.tv_detail_iuran_nominal);
        tvJatuhTempo = findViewById(R.id.tv_detail_iuran_jatuh_tempo);
        tvCreatedAt = findViewById(R.id.tv_detail_iuran_created_at);

        // Inisialisasi Views Form Pembayaran
        etJumlahBayar = findViewById(R.id.et_jumlah_bayar);
        rgPaymentMethod = findViewById(R.id.rg_payment_method);
        rbVirtual = findViewById(R.id.rb_virtual);
        rbCash = findViewById(R.id.rb_cash);
        layoutBuktiPembayaran = findViewById(R.id.layout_bukti_pembayaran);
        ivBuktiBayarPreview = findViewById(R.id.iv_bukti_bayar_preview);
        btnPilihBukti = findViewById(R.id.btn_pilih_bukti);
        btnBayarIuran = findViewById(R.id.btn_bayar_iuran);

        // Ambil iuran_id dari Intent
        iuranId = getIntent().getIntExtra("iuran_id", -1);
        if (iuranId != -1) {
            loadIuranDetail(iuranId);
        } else {
            Toast.makeText(this, "ID Iuran tidak valid.", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        // Ambil user_id dari SharedPreferences
        SharedPreferences sharedPreferences = getSharedPreferences("LoginData", Context.MODE_PRIVATE);
        userId = sharedPreferences.getInt("user_id", -1);
        if (userId == -1) {
            Toast.makeText(this, "User ID tidak ditemukan. Harap login kembali.", Toast.LENGTH_LONG).show();
            // Opsional: Arahkan kembali ke LoginActivity jika user_id tidak ada
            Intent intent = new Intent(PembayaranDetailActivity.this, LoginActivity.class);
            startActivity(intent);
            finish();
            return; // Penting: tambahkan return agar tidak melanjutkan proses tanpa user_id
        }

        // Listener untuk RadioGroup metode pembayaran
        rgPaymentMethod.setOnCheckedChangeListener((group, checkedId) -> {
            if (checkedId == R.id.rb_virtual) {
                layoutBuktiPembayaran.setVisibility(View.VISIBLE);
            } else {
                layoutBuktiPembayaran.setVisibility(View.GONE);
                selectedBuktiBitmap = null; // Reset gambar jika ganti ke cash
                ivBuktiBayarPreview.setImageResource(R.drawable.ic_image_placeholder); // Reset preview
            }
        });

        // Listener untuk tombol Pilih Bukti Pembayaran
        btnPilihBukti.setOnClickListener(v -> openImageChooser());

        // Listener untuk tombol Bayar Iuran
        btnBayarIuran.setOnClickListener(v -> submitPembayaran());
    }

    private void loadIuranDetail(int id) {
        StringRequest stringRequest = new StringRequest(Request.Method.POST, Constants.URL_GET_IURAN_DETAIL,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            JSONObject jsonObject = new JSONObject(response);
                            String status = jsonObject.getString("status");
                            String message = jsonObject.getString("message");

                            if (status.equals("success")) {
                                JSONObject data = jsonObject.getJSONObject("data");
                                tvJudul.setText("Judul Iuran: " + data.getString("judul"));
                                tvDeskripsi.setText("Deskripsi: " + data.getString("deskripsi"));
                                int nominal = data.getInt("nominal");
                                // Format nominal menjadi mata uang Rupiah
                                NumberFormat formatRupiah = NumberFormat.getCurrencyInstance(new Locale("in", "ID"));
                                tvNominal.setText("Nominal: " + formatRupiah.format(nominal));
                                etJumlahBayar.setText(String.valueOf(nominal)); // Isi otomatis jumlah bayar
                                tvJatuhTempo.setText("Jatuh Tempo: " + data.getString("jatuh_tempo"));
                                tvCreatedAt.setText("Tanggal Publikasi: " + data.getString("created_at"));

                            } else {
                                Toast.makeText(PembayaranDetailActivity.this, message, Toast.LENGTH_LONG).show();
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                            Toast.makeText(PembayaranDetailActivity.this, "Error parsing JSON detail iuran: " + e.getMessage(), Toast.LENGTH_LONG).show();
                            Log.e("PembayaranDetail", "JSON Error: " + e.getMessage());
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(PembayaranDetailActivity.this, "Error koneksi: " + error.getMessage(), Toast.LENGTH_LONG).show();
                        if (error.networkResponse != null) {
                            String responseBody = new String(error.networkResponse.data);
                            Log.e("VolleyError", "Response Body Iuran Detail: " + responseBody);
                        }
                    }
                }) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                params.put("iuran_id", String.valueOf(id));
                return params;
            }
        };

        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);
    }

    private void openImageChooser() {
        Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        intent.setType("image/*");
        pickImageLauncher.launch(intent);
    }

    // Method untuk mengonversi Bitmap menjadi String Base64
    private String imageToBase64(Bitmap bitmap) {
        if (bitmap == null) {
            return "";
        }
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.JPEG, 70, byteArrayOutputStream); // Kompresi 70%
        byte[] byteArray = byteArrayOutputStream.toByteArray();
        return Base64.encodeToString(byteArray, Base64.DEFAULT);
    }

    private void submitPembayaran() {
        final String jumlahBayarStr = etJumlahBayar.getText().toString().trim();
        final String paymentMethod = rbVirtual.isChecked() ? "virtual" : "cash";

        if (jumlahBayarStr.isEmpty()) {
            Toast.makeText(this, "Jumlah pembayaran tidak boleh kosong!", Toast.LENGTH_SHORT).show();
            return;
        }
        if (userId == -1) {
            Toast.makeText(this, "User ID tidak valid. Mohon login kembali.", Toast.LENGTH_SHORT).show();
            return;
        }

        final int jumlahBayar = Integer.parseInt(jumlahBayarStr);
        final String fotoBase64 = (paymentMethod.equals("virtual")) ? imageToBase64(selectedBuktiBitmap) : "";

        if (paymentMethod.equals("virtual") && selectedBuktiBitmap == null) {
            Toast.makeText(this, "Silakan pilih bukti pembayaran untuk Virtual Transfer.", Toast.LENGTH_SHORT).show();
            return;
        }

        StringRequest stringRequest = new StringRequest(Request.Method.POST, Constants.URL_SUBMIT_PEMBAYARAN_IURAN,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            JSONObject jsonObject = new JSONObject(response);
                            String status = jsonObject.getString("status");
                            String message = jsonObject.getString("message");

                            if (status.equals("success")) {
                                Toast.makeText(PembayaranDetailActivity.this, message, Toast.LENGTH_LONG).show();
                                finish(); // Kembali ke Activity sebelumnya setelah berhasil
                            } else {
                                Toast.makeText(PembayaranDetailActivity.this, message, Toast.LENGTH_LONG).show();
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                            Toast.makeText(PembayaranDetailActivity.this, "Error parsing JSON: " + e.getMessage(), Toast.LENGTH_LONG).show();
                            Log.e("PembayaranDetail", "JSON parsing error: " + e.getMessage());
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(PembayaranDetailActivity.this, "Error koneksi: " + error.getMessage(), Toast.LENGTH_LONG).show();
                        if (error.networkResponse != null) {
                            String responseBody = new String(error.networkResponse.data);
                            Log.e("VolleyError", "Response Body Pembayaran: " + responseBody);
                        }
                    }
                }) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                params.put("iuran_id", String.valueOf(iuranId));
                params.put("user_id", String.valueOf(userId));
                params.put("jumlah", String.valueOf(jumlahBayar));
                params.put("bukti_type", paymentMethod);
                if (paymentMethod.equals("virtual")) {
                    params.put("foto", fotoBase64); // Kirim gambar Base64 hanya jika virtual
                }
                return params;
            }
        };

        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);
    }
}