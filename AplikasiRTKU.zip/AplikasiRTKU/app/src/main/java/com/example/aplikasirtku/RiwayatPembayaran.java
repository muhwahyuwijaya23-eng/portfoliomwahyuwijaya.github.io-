// app/src/main/java/com/example/aplikasirtku/RiwayatPembayaran.java
package com.example.aplikasirtku;

public class RiwayatPembayaran {
    private int id;
    private String iuranJudul;
    private String status;
    private String tanggalBayar;
    private int jumlahBayar;

    public RiwayatPembayaran(int id, String iuranJudul, String status, String tanggalBayar, int jumlahBayar) {
        this.id = id;
        this.iuranJudul = iuranJudul;
        this.status = status;
        this.tanggalBayar = tanggalBayar;
        this.jumlahBayar = jumlahBayar;
    }

    // --- Getter Methods ---
    public int getId() { return id; }
    public String getIuranJudul() { return iuranJudul; }
    public String getStatus() { return status; }
    public String getTanggalBayar() { return tanggalBayar; }
    public int getJumlahBayar() { return jumlahBayar; }
}