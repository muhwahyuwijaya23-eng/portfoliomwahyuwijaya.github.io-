// app/src/main/java/com/example/aplikasirtku/RiwayatPembayaranAdapter.java
package com.example.aplikasirtku;

import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.text.NumberFormat;
import java.util.List;
import java.util.Locale;

public class RiwayatPembayaranAdapter extends RecyclerView.Adapter<RiwayatPembayaranAdapter.RiwayatPembayaranViewHolder> {

    private Context context;
    private List<RiwayatPembayaran> riwayatList;

    public RiwayatPembayaranAdapter(Context context, List<RiwayatPembayaran> riwayatList) {
        this.context = context;
        this.riwayatList = riwayatList;
    }

    @NonNull
    @Override
    public RiwayatPembayaranViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_riwayat_pembayaran, parent, false);
        return new RiwayatPembayaranViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull RiwayatPembayaranViewHolder holder, int position) {
        RiwayatPembayaran riwayat = riwayatList.get(position);
        holder.tvIuranJudul.setText(riwayat.getIuranJudul());
        holder.tvTanggalBayar.setText("Tanggal Bayar: " + riwayat.getTanggalBayar());
        holder.tvStatus.setText("Status: " + riwayat.getStatus());

        // Atur warna status
        if (riwayat.getStatus().equalsIgnoreCase("Dikonfirmasi")) {
            holder.tvStatus.setTextColor(Color.parseColor("#4CAF50")); // Hijau
        } else if (riwayat.getStatus().equalsIgnoreCase("Menunggu")) {
            holder.tvStatus.setTextColor(Color.parseColor("#FFC107")); // Kuning
        } else {
            holder.tvStatus.setTextColor(Color.parseColor("#F44336")); // Merah
        }

        NumberFormat formatRupiah = NumberFormat.getCurrencyInstance(new Locale("in", "ID"));
        holder.tvJumlahBayar.setText("Jumlah: " + formatRupiah.format(riwayat.getJumlahBayar()));
    }

    @Override
    public int getItemCount() {
        return riwayatList.size();
    }

    public static class RiwayatPembayaranViewHolder extends RecyclerView.ViewHolder {
        TextView tvIuranJudul, tvStatus, tvTanggalBayar, tvJumlahBayar;

        public RiwayatPembayaranViewHolder(@NonNull View itemView) {
            super(itemView);
            tvIuranJudul = itemView.findViewById(R.id.tv_riwayat_iuran_judul);
            tvStatus = itemView.findViewById(R.id.tv_riwayat_status);
            tvTanggalBayar = itemView.findViewById(R.id.tv_riwayat_tanggal_bayar);
            tvJumlahBayar = itemView.findViewById(R.id.tv_riwayat_jumlah_bayar);
        }
    }
}