// app/src/main/java/com/example/aplikasirtku/SettingActivity.java
package com.example.aplikasirtku;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

import android.util.TypedValue; // <--- TAMBAHKAN BARIS INI
import android.graphics.Typeface; // <--- Mungkin juga butuh ini jika tidak otomatis

public class SettingActivity extends AppCompatActivity {

    private Button btnGantiPassword, btnUbahProfile, btnSimpanProfile, btnBatalEditProfile;
    private TextView tvNamaLengkap, tvAlamat, tvNoTelepon, tvRt, tvRw;
    private LinearLayout layoutEditButtons;

    private TextInputEditText etNamaLengkap, etAlamat, etNoTelepon, etRt, etRw;
    private TextInputLayout tilNamaLengkap, tilAlamat, tilNoTelepon, tilRt, tilRw;

    private int userId;
    private boolean isEditingProfile = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_setting);

        btnGantiPassword = findViewById(R.id.btn_ganti_password);
        btnUbahProfile = findViewById(R.id.btn_ubah_profile);
        btnSimpanProfile = findViewById(R.id.btn_simpan_profile);
        btnBatalEditProfile = findViewById(R.id.btn_batal_edit_profile);
        layoutEditButtons = findViewById(R.id.layout_edit_buttons);

        tvNamaLengkap = findViewById(R.id.tv_nama_lengkap);
        tvAlamat = findViewById(R.id.tv_alamat);
        tvNoTelepon = findViewById(R.id.tv_no_telepon);
        tvRt = findViewById(R.id.tv_rt);
        tvRw = findViewById(R.id.tv_rw);

        SharedPreferences sharedPreferences = getSharedPreferences("LoginData", Context.MODE_PRIVATE);
        userId = sharedPreferences.getInt("user_id", -1);

        if (userId == -1) {
            Toast.makeText(this, "User ID tidak ditemukan. Harap login kembali.", Toast.LENGTH_LONG).show();
            Intent intent = new Intent(SettingActivity.this, LoginActivity.class);
            startActivity(intent);
            finish();
            return;
        }

        loadProfileData(userId);

        btnGantiPassword.setOnClickListener(v -> {
            Intent intent = new Intent(SettingActivity.this, ChangePasswordActivity.class);
            startActivity(intent);
        });

        btnUbahProfile.setOnClickListener(v -> {
            toggleEditMode(true);
        });

        btnSimpanProfile.setOnClickListener(v -> {
            saveProfileData();
        });

        btnBatalEditProfile.setOnClickListener(v -> {
            toggleEditMode(false);
            loadProfileData(userId);
        });

        BottomNavigationView bottomNavigationView = findViewById(R.id.bottom_navigation_setting);
        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                Intent intent;
                int itemId = item.getItemId();
                if (itemId == R.id.navigation_home) {
                    intent = new Intent(SettingActivity.this, MainActivity.class);
                    startActivity(intent);
                    finish();
                    return true;
                } else if (itemId == R.id.navigation_person) {
                    intent = new Intent(SettingActivity.this, AccountActivity.class);
                    startActivity(intent);
                    finish();
                    return true;
                } else if (itemId == R.id.navigation_notifications) {
                    intent = new Intent(SettingActivity.this, NotificationsActivity.class);
                    startActivity(intent);
                    finish();
                    return true;
                } else if (itemId == R.id.navigation_settings) {
                    return true;
                }
                return false;
            }
        });
        bottomNavigationView.setSelectedItemId(R.id.navigation_settings);
    }

    private void loadProfileData(int userId) {
        StringRequest stringRequest = new StringRequest(Request.Method.POST, Constants.URL_GET_WARGA_PROFILE,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            JSONObject jsonObject = new JSONObject(response);
                            String status = jsonObject.getString("status");
                            String message = jsonObject.getString("message");

                            if (status.equals("success")) {
                                JSONObject data = jsonObject.getJSONObject("data");
                                tvNamaLengkap.setText(data.getString("nama"));
                                tvAlamat.setText(data.getString("alamat"));
                                tvNoTelepon.setText(data.getString("no_telepon"));
                                tvRt.setText(data.getString("rt"));
                                tvRw.setText(data.getString("rw"));
                            } else {
                                Toast.makeText(SettingActivity.this, message, Toast.LENGTH_LONG).show();
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                            Toast.makeText(SettingActivity.this, "Error parsing JSON profil: " + e.getMessage(), Toast.LENGTH_LONG).show();
                            Log.e("SettingActivity", "JSON parsing error (loadProfileData): " + e.getMessage());
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(SettingActivity.this, "Error koneksi: " + error.getMessage(), Toast.LENGTH_LONG).show();
                        if (error.networkResponse != null) {
                            String responseBody = new String(error.networkResponse.data);
                            Log.e("SettingActivity", "Volley Error (loadProfileData): " + responseBody);
                        }
                    }
                }) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                params.put("user_id", String.valueOf(userId));
                return params;
            }
        };

        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);
    }

    private void toggleEditMode(boolean enableEdit) {
        isEditingProfile = enableEdit;

        if (enableEdit) {
            btnUbahProfile.setVisibility(View.GONE);
            layoutEditButtons.setVisibility(View.VISIBLE);

            // Ganti TextView menjadi EditText
            replaceTextViewWithEditText(tvNamaLengkap, "nama");
            replaceTextViewWithEditText(tvAlamat, "alamat");
            replaceTextViewWithEditText(tvNoTelepon, "no_telepon");
            replaceTextViewWithEditText(tvRt, "rt");
            replaceTextViewWithEditText(tvRw, "rw");

            Toast.makeText(this, "Anda dalam mode edit profil.", Toast.LENGTH_SHORT).show();

        } else {
            btnUbahProfile.setVisibility(View.VISIBLE);
            layoutEditButtons.setVisibility(View.GONE);

            // Ganti EditText kembali menjadi TextView (dengan data yang mungkin sudah diubah)
            replaceEditTextWithTextView(tvNamaLengkap);
            replaceEditTextWithTextView(tvAlamat);
            replaceEditTextWithTextView(tvNoTelepon);
            replaceEditTextWithTextView(tvRt);
            replaceEditTextWithTextView(tvRw);
        }
    }

    private void replaceTextViewWithEditText(TextView textView, String tag) {
        LinearLayout parent = (LinearLayout) textView.getParent();
        int index = parent.indexOfChild(textView);
        String currentText = textView.getText().toString();

        TextInputLayout textInputLayout = new TextInputLayout(this, null, com.google.android.material.R.attr.textInputStyle);
        TextInputEditText editText = new TextInputEditText(textInputLayout.getContext());
        editText.setText(currentText);
        editText.setSingleLine(true);

        if (tag.equals("no_telepon")) {
            editText.setInputType(android.text.InputType.TYPE_CLASS_PHONE);
        } else if (tag.equals("rt") || tag.equals("rw")) {
            editText.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);
        } else if (tag.equals("alamat")) {
            editText.setSingleLine(false);
            editText.setLines(3);
            editText.setGravity(android.view.Gravity.TOP);
        }

        textInputLayout.setTag("til_" + tag);
        editText.setTag("et_" + tag);

        textInputLayout.addView(editText, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
        ));

        parent.removeView(textView);
        parent.addView(textInputLayout, index, textView.getLayoutParams());

        switch (tag) {
            case "nama": etNamaLengkap = editText; tilNamaLengkap = textInputLayout; break;
            case "alamat": etAlamat = editText; tilAlamat = textInputLayout; break;
            case "no_telepon": etNoTelepon = editText; tilNoTelepon = textInputLayout; break;
            case "rt": etRt = editText; tilRt = textInputLayout; break;
            case "rw": etRw = editText; tilRw = textInputLayout; break;
        }
    }

    private void replaceEditTextWithTextView(TextView originalTextView) {
        LinearLayout parent = (LinearLayout) originalTextView.getParent();
        int index = -1;
        TextInputLayout textInputLayoutToRemove = null;

        String tagIdentifier = "";
        if (originalTextView.getId() == R.id.tv_nama_lengkap) tagIdentifier = "nama";
        else if (originalTextView.getId() == R.id.tv_alamat) tagIdentifier = "alamat";
        else if (originalTextView.getId() == R.id.tv_no_telepon) tagIdentifier = "no_telepon";
        else if (originalTextView.getId() == R.id.tv_rt) tagIdentifier = "rt";
        else if (originalTextView.getId() == R.id.tv_rw) tagIdentifier = "rw";

        for (int i = 0; i < parent.getChildCount(); i++) {
            View child = parent.getChildAt(i);
            if (child instanceof TextInputLayout && child.getTag() != null) {
                String tag = (String) child.getTag();
                if (tag.equals("til_" + tagIdentifier)) {
                    textInputLayoutToRemove = (TextInputLayout) child;
                    index = i;
                    break;
                }
            }
        }

        String newText = originalTextView.getText().toString(); // Default ke teks asli (jika dibatalkan)
        if (textInputLayoutToRemove != null && textInputLayoutToRemove.getEditText() != null) {
            newText = textInputLayoutToRemove.getEditText().getText().toString(); // Ambil teks dari EditText
        }

        TextView newTextView = new TextView(this);
        newTextView.setText(newText);
        // --- PERBAIKAN DI SINI ---
        newTextView.setTextSize(TypedValue.COMPLEX_UNIT_PX, originalTextView.getTextSize());
        newTextView.setTextColor(originalTextView.getTextColors());
        newTextView.setLayoutParams(originalTextView.getLayoutParams());
        newTextView.setTag(originalTextView.getTag());
        newTextView.setId(originalTextView.getId());
        newTextView.setTypeface(null, originalTextView.getTypeface().getStyle()); // <--- PERBAIKAN DI SINI
        // --- AKHIR PERBAIKAN ---

        if (textInputLayoutToRemove != null) {
            parent.removeViewAt(index);
            parent.addView(newTextView, index);
        }

        if (originalTextView.getId() == R.id.tv_nama_lengkap) { tvNamaLengkap = newTextView; etNamaLengkap = null; tilNamaLengkap = null; }
        else if (originalTextView.getId() == R.id.tv_alamat) { tvAlamat = newTextView; etAlamat = null; tilAlamat = null; }
        else if (originalTextView.getId() == R.id.tv_no_telepon) { tvNoTelepon = newTextView; etNoTelepon = null; tilNoTelepon = null; }
        else if (originalTextView.getId() == R.id.tv_rt) { tvRt = newTextView; etRt = null; tilRt = null; }
        else if (originalTextView.getId() == R.id.tv_rw) { tvRw = newTextView; etRw = null; tilRw = null; }
    }


    private void saveProfileData() {
        final String nama = etNamaLengkap != null ? etNamaLengkap.getText().toString().trim() : tvNamaLengkap.getText().toString().trim();
        final String alamat = etAlamat != null ? etAlamat.getText().toString().trim() : tvAlamat.getText().toString().trim();
        final String noTelepon = etNoTelepon != null ? etNoTelepon.getText().toString().trim() : tvNoTelepon.getText().toString().trim();
        final String rt = etRt != null ? etRt.getText().toString().trim() : tvRt.getText().toString().trim();
        final String rw = etRw != null ? etRw.getText().toString().trim() : tvRw.getText().toString().trim();

        if (nama.isEmpty() || alamat.isEmpty() || noTelepon.isEmpty() || rt.isEmpty() || rw.isEmpty()) {
            Toast.makeText(this, "Semua data profil harus diisi.", Toast.LENGTH_SHORT).show();
            return;
        }

        StringRequest stringRequest = new StringRequest(Request.Method.POST, Constants.URL_UPDATE_WARGA_PROFILE,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            JSONObject jsonObject = new JSONObject(response);
                            String status = jsonObject.getString("status");
                            String message = jsonObject.getString("message");

                            if (status.equals("success")) {
                                Toast.makeText(SettingActivity.this, message, Toast.LENGTH_LONG).show();
                                toggleEditMode(false);
                                loadProfileData(userId);
                            } else {
                                Toast.makeText(SettingActivity.this, message, Toast.LENGTH_LONG).show();
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                            Toast.makeText(SettingActivity.this, "Error parsing JSON (saveProfileData): " + e.getMessage(), Toast.LENGTH_LONG).show();
                            Log.e("SettingActivity", "JSON parsing error (saveProfileData): " + e.getMessage());
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(SettingActivity.this, "Error koneksi (saveProfileData): " + error.getMessage(), Toast.LENGTH_LONG).show();
                        if (error.networkResponse != null) {
                            String responseBody = new String(error.networkResponse.data);
                            Log.e("SettingActivity", "Volley Error (saveProfileData): " + responseBody);
                        }
                    }
                }) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                params.put("user_id", String.valueOf(userId));
                params.put("nama", nama);
                params.put("alamat", alamat);
                params.put("no_telepon", noTelepon);
                params.put("rt", rt);
                params.put("rw", rw);
                return params;
            }
        };

        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);
    }
}