// app/src/main/java/com/example/aplikasirtku/StatusPembayaranActivity.java
package com.example.aplikasirtku;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;    // <--- TAMBAHKAN INI
import java.util.HashMap; // <--- TAMBAHKAN INI

public class StatusPembayaranActivity extends AppCompatActivity {

    private RecyclerView rvRiwayatPembayaran;
    private RiwayatPembayaranAdapter adapter;
    private List<RiwayatPembayaran> riwayatList;
    private int userId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_status_pembayaran);

        rvRiwayatPembayaran = findViewById(R.id.rv_riwayat_pembayaran);
        rvRiwayatPembayaran.setLayoutManager(new LinearLayoutManager(this));
        riwayatList = new ArrayList<>();
        adapter = new RiwayatPembayaranAdapter(this, riwayatList);
        rvRiwayatPembayaran.setAdapter(adapter);

        // Ambil user_id dari SharedPreferences
        SharedPreferences sharedPreferences = getSharedPreferences("LoginData", Context.MODE_PRIVATE);
        userId = sharedPreferences.getInt("user_id", -1);

        if (userId != -1) {
            loadPaymentHistory(userId);
        } else {
            Toast.makeText(this, "User ID tidak ditemukan. Harap login kembali.", Toast.LENGTH_LONG).show();
            Intent intent = new Intent(StatusPembayaranActivity.this, LoginActivity.class);
            startActivity(intent);
            finish();
        }
    }

    private void loadPaymentHistory(int userId) {
        StringRequest stringRequest = new StringRequest(Request.Method.POST, Constants.URL_GET_PAYMENT_HISTORY,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            JSONObject jsonObject = new JSONObject(response);
                            String status = jsonObject.getString("status");
                            String message = jsonObject.getString("message");

                            if (status.equals("success")) {
                                JSONArray jsonArray = jsonObject.getJSONArray("data");
                                riwayatList.clear(); // Hapus data lama
                                for (int i = 0; i < jsonArray.length(); i++) {
                                    JSONObject historyObj = jsonArray.getJSONObject(i);
                                    int id = historyObj.getInt("id");
                                    String iuranJudul = historyObj.getString("iuran_judul");
                                    String paymentStatus = historyObj.getString("payment_status");
                                    String paidDate = historyObj.getString("paid_date");
                                    int paidAmount = historyObj.getInt("paid_amount");

                                    RiwayatPembayaran riwayat = new RiwayatPembayaran(id, iuranJudul, paymentStatus, paidDate, paidAmount);
                                    riwayatList.add(riwayat);
                                }
                                adapter.notifyDataSetChanged();
                                if (riwayatList.isEmpty()) {
                                    Toast.makeText(StatusPembayaranActivity.this, "Belum ada riwayat pembayaran.", Toast.LENGTH_SHORT).show();
                                }
                            } else {
                                Toast.makeText(StatusPembayaranActivity.this, message, Toast.LENGTH_LONG).show();
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                            Toast.makeText(StatusPembayaranActivity.this, "Error parsing JSON riwayat pembayaran: " + e.getMessage(), Toast.LENGTH_LONG).show();
                            Log.e("StatusPembayaran", "JSON parsing error: " + e.getMessage());
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(StatusPembayaranActivity.this, "Error koneksi: " + error.getMessage(), Toast.LENGTH_LONG).show();
                        if (error.networkResponse != null) {
                            String responseBody = new String(error.networkResponse.data);
                            Log.e("VolleyError", "Response Body Riwayat: " + responseBody);
                        }
                    }
                }) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                params.put("user_id", String.valueOf(userId));
                return params;
            }
        };

        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);
    }
}