package com.example.aplikasirtku;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.material.bottomnavigation.BottomNavigationView;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class SuratmenyuratActivity extends AppCompatActivity {

    private EditText etNama, etKeterangan; // Mengganti etJudul dan etIsi agar lebih deskriptif
    private Button btnKirim;
    private int userId; // Untuk menyimpan user_id dari SharedPreferences

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_suratmenyurat); // Pastikan nama layout benar

        etNama = findViewById(R.id.et_judul); // Layout menggunakan id et_judul untuk NAMA
        etKeterangan = findViewById(R.id.et_isi); // Layout menggunakan id et_isi untuk Keterangan Pemohon
        btnKirim = findViewById(R.id.btn_kirim);

        // Ambil user_id dari SharedPreferences
        SharedPreferences sharedPreferences = getSharedPreferences("LoginData", Context.MODE_PRIVATE);
        userId = sharedPreferences.getInt("user_id", -1); // -1 adalah nilai default jika tidak ditemukan

        if (userId == -1) {
            Toast.makeText(this, "User ID tidak ditemukan. Harap login kembali.", Toast.LENGTH_LONG).show();
            // Opsional: Arahkan kembali ke LoginActivity jika user_id tidak ada
            Intent intent = new Intent(SuratmenyuratActivity.this, LoginActivity.class);
            startActivity(intent);
            finish();
        }

        btnKirim.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                submitPermohonanSurat();
            }
        });

        // Setup BottomNavigationView (sesuaikan jika ada di layout ini)
        BottomNavigationView bottomNavigationView = findViewById(R.id.bottom_navigation);
        if (bottomNavigationView != null) {
            bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
                @Override
                public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                    Intent intent;
                    int itemId = item.getItemId();
                    if (itemId == R.id.navigation_home) {
                        intent = new Intent(SuratmenyuratActivity.this, MainActivity.class);
                        startActivity(intent);
                        finish();
                        return true;
                    } else if (itemId == R.id.navigation_person) {
                        intent = new Intent(SuratmenyuratActivity.this, AccountActivity.class);
                        startActivity(intent);
                        finish();
                        return true;
                    } else if (itemId == R.id.navigation_notifications) {
                        intent = new Intent(SuratmenyuratActivity.this, NotificationsActivity.class);
                        startActivity(intent);
                        finish();
                        return true;
                    } else if (itemId == R.id.navigation_settings) {
                        intent = new Intent(SuratmenyuratActivity.this, SettingActivity.class);
                        startActivity(intent);
                        finish();
                        return true;
                    }
                    return false;
                }
            });
        }
    }

    private void submitPermohonanSurat() {
        final String namaPemohon = etNama.getText().toString().trim();
        final String keteranganPemohon = etKeterangan.getText().toString().trim();

        if (namaPemohon.isEmpty() || keteranganPemohon.isEmpty()) {
            Toast.makeText(this, "Nama dan Keterangan Pemohon tidak boleh kosong!", Toast.LENGTH_SHORT).show();
            return;
        }
        if (userId == -1) {
            Toast.makeText(this, "User ID tidak valid. Mohon login kembali.", Toast.LENGTH_SHORT).show();
            return;
        }

        StringRequest stringRequest = new StringRequest(Request.Method.POST, Constants.URL_SUBMIT_SURAT_PERMOHONAN,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            JSONObject jsonObject = new JSONObject(response);
                            String status = jsonObject.getString("status");
                            String message = jsonObject.getString("message");

                            if (status.equals("success")) {
                                Toast.makeText(SuratmenyuratActivity.this, message, Toast.LENGTH_LONG).show();
                                finish(); // Kembali ke Activity sebelumnya setelah berhasil
                            } else {
                                Toast.makeText(SuratmenyuratActivity.this, message, Toast.LENGTH_LONG).show();
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                            Toast.makeText(SuratmenyuratActivity.this, "Error parsing JSON: " + e.getMessage(), Toast.LENGTH_LONG).show();
                            Log.e("SuratmenyuratActivity", "JSON parsing error: " + e.getMessage());
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(SuratmenyuratActivity.this, "Error koneksi: " + error.getMessage(), Toast.LENGTH_LONG).show();
                        if (error.networkResponse != null) {
                            String responseBody = new String(error.networkResponse.data);
                            Log.e("SuratmenyuratActivity", "Volley Error Response: " + responseBody);
                        }
                    }
                }) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                params.put("user_id", String.valueOf(userId));
                params.put("nama_pemohon", namaPemohon); // Mengirim 'nama' sebagai 'judul'
                params.put("keterangan_pemohon", keteranganPemohon); // Mengirim 'keterangan' sebagai 'isi'
                return params;
            }
        };

        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);
    }
}